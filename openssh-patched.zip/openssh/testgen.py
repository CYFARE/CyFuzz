import re
import codecs

# Read the strace log from a file
with open('strace.log', 'r') as f:
    strace_log = f.read()

# Regular expression to match write(3, data, len) calls
write_pattern = re.compile(r'write\(3, "(.*)", \d+\) = \d+')

# List to store the data chunks
data_chunks = []

# Iterate over each line in the strace log
for line in strace_log.strip().split('\n'):
    match = write_pattern.search(line)
    if match:
        data_str = match.group(1)
        # Decode the escaped string into bytes
        data_bytes, _ = codecs.escape_decode(data_str)
        data_chunks.append(data_bytes)

# Generate the Python script
with open('client_output.py', 'w') as f:
    f.write('import sys\n\n')
    f.write('data_chunks = [\n')
    for chunk in data_chunks:
        # Represent the byte string in a Python-compatible format
        chunk_repr = repr(chunk)
        f.write(f'    {chunk_repr},\n')
    f.write(']\n\n')
    f.write('for chunk in data_chunks:\n')
    f.write('    sys.stdout.buffer.write(chunk)\n')
